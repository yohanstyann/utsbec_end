<?php

$con = mysqli_connect("localhost", "root", "", "bb214_db");